create database AB_MD;
use  AB_MD;

create table Usuarios(
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,

  NomUsu VARCHAR(100) NOT NULL,

  Email VARCHAR(100) UNIQUE NOT NULL,

  Contraseña VARCHAR(100) NOT NULL,

  Imagen VARCHAR(100) DEFAULT NULL
);
