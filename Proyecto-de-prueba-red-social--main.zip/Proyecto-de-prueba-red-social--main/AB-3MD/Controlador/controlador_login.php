<?php
session_start();
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'ab_md';
// Establish database connection
$conn = mysqli_connect($hostname, $username, $password, $database);
// Check connection
if(!$conn){
die('Connection failed: ' . mysqli_connect_error());
}

$nombre= $_POST["nombre"];
$email=$_POST["email"];
$contraseña=$_POST["contraseña"];


// Make query
$query = "SELECT * FROM usuarios WHERE Email = '$email' AND Contraseña = '$contraseña'";
$result = mysqli_query($conn, $query);
$usuarios = [];
while($row = mysqli_fetch_assoc($result)) {
$usuarios[] = $row;
}


if(empty($usuarios)){
    header("location:../Vista/error.php");
}else{
    $_SESSION["email"]=$usuarios[0]["Email"];
     header("location:../Vista/perfil.php?perfil=$nombre");
}


/*foreach ($usuarios as $usuario) {
echo "Nombre: " . $usuario["NomUsu"] . "<br>";
}

$i=-1;
$login=false;
while($login==false){
    $i=$i+1;
    if($nombre==$usuarios[$i]["NomUsu"]&&$email==$usuarios[$i]["Email"]&&$contraseña==$usuarios[$i]["Contraseña"]){
        header("location:../Vista/perfil.php");
        $login=true;
        exit();
    }else{
        header("location:../Vista/index.php");
        $login=false;
        exit();
    }
}
*/
?>