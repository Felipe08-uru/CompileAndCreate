<?php
class Usuario
{
	private $conn;

	// Constructor que recibe la conexión a la base de datos
	public function __construct($conn)
	{
		$this->conn = $conn;
	}

	// Métodos para manejar usuarios
	// Obtener todos los usuarios (método GET, endopoint: /usuarios)
	public function getAllUsuarios()
	{
		$query = "SELECT * FROM usuarios";
		$result = mysqli_query($this->conn, $query);
		$usuarios = [];
		while($row = mysqli_fetch_assoc($result)) {
			$usuarios[] = $row;
		}
		return $usuarios;
	}
	// Obtener un usuario por ID  (método GET, endopoint: /usuarios/<id>)
	public function getUsuarioById($id)
	{
		$query = "SELECT * FROM usuarios WHERE id = $id ";
		$result = mysqli_query($this->conn, $query);
		$usuario = mysqli_fetch_assoc($result);
		return $usuario;
	}
	// Agregar un nuevo usuario (método POST, endopoint: /usuarios)
	public function addUsuario($data){
		if(!isset($data['NomUsu']) || !isset($data['Imagen']) || !isset($data['Email']) || !isset($data['Contraseña'])) {
			http_response_code(400);
			return json_encode(["error" => "Datos incompletos"]);
		}else{
			$usr_name = $data['NomUsu'];
			$usr_email = $data['Email'];
			$usr_pass = password_hash($data['Contraseña'], PASSWORD_DEFAULT);
			$img_data = $data['Imagen'];
			// Procesar imagen base64
			if (preg_match('/^data:image\/(\w+);base64,/', $img_data, $type)) {
				$img_data = substr($img_data, strpos($img_data, ',') + 1);
				$img_data = base64_decode($img_data);
				$ext = strtolower($type[1]);
				$img_name = uniqid() . "." . $ext;
				$img_path = __DIR__ . "/imagenes/" . $img_name;
				if (!is_dir(__DIR__ . "/imagenes/")) {
					mkdir(__DIR__ . "/imagenes/", 0777, true);
				}
				try{
					$query = "INSERT INTO usuario (NomUsu, Email, Contraseña, Imagen) VALUES ('$usr_name', '$usr_email', '$usr_pass', '$img_name')";
					$result = mysqli_query($this->conn, $query);
				} catch (mysqli_sql_exception $e) {
					http_response_code(500);
					return json_encode(["error" => "Error en la base de datos: " . $e->getMessage()]);
				}
				if($result){
					if (file_put_contents($img_path, $img_data) === false) {
						http_response_code(500);
						return json_encode(["error" => "No se pudo guardar la imagen"]);
					}
					http_response_code(201);
					return json_encode(["success" => "Usuario registrado con éxito"]);
				} else {
					http_response_code(400);
					return json_encode(["error" => "No se pudo registrar el usuario"]);
				}
			} else {
				http_response_code(400);
				return json_encode(["error" => "Formato de imagen inválido"]);
			}
		}
	}

	// Iniciar sesión de usuario (método POST, endopoint: /login)
	public function loginUsuario($data){
		if(!isset($data['Email']) || !isset($data['Contraseña'])) {
			http_response_code(400);
			return json_encode(["error" => "Datos incompletos"]);
		}else{
			$usr_email = $data['Email'];
			$usr_pass = $data['Contraseña'];
			$query = "SELECT * FROM usuarios WHERE Email = '$usr_email'";
			$result = mysqli_query($this->conn, $query);
			if(mysqli_num_rows($result) > 0){
				$usuario = mysqli_fetch_assoc($result);
				if(password_verify($usr_pass, $usuario['Contraseña'])){
					$result = mysqli_query($this->conn, $query);
					http_response_code(200);
					return json_encode(["success" => [$usuario['NomUsu'], $usr_email]])	;
				} else {
					http_response_code(400);
					return json_encode(["error" => "Contraseña incorrecta"]);
				}
			} else {
				http_response_code(400);
				return json_encode(["error" => "Usuario no encontrado"]);
			}
		}
	}
}
?>