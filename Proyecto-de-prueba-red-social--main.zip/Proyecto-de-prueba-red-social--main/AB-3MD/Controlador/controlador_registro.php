<?php
$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'ab_md';
$conn = mysqli_connect($hostname, $username, $password, $database);
if (!$conn) {
  die('Connection failed: ' . mysqli_connect_error());
}

$nombre = $_POST["nombre"];
$email = $_POST["email"];
$contraseña = $_POST["contraseña"];
$confContraseña = $_POST["confContraseña"];


$target_dir = "imagenes/";
 echo $_FILES['FotoPerfil']['error'];
if (isset($_FILES['FotoPerfil']) && $_FILES['FotoPerfil']['error'] === UPLOAD_ERR_OK) {
  $target_file = $target_dir . basename($_FILES['FotoPerfil']["name"]);
  $uploadOk = 1;
  $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
  $imagen = ($_FILES['FotoPerfil']['name']);

  if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
  }

  if ($_FILES['FotoPerfil']['size'] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
  }

  if (
    $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif"
  ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
  }

  if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
  } else {


    if (move_uploaded_file($_FILES["FotoPerfil"]["tmp_name"], $target_file)) {
      echo "The file " . htmlspecialchars(basename($_FILES["FotoPerfil"]["name"])) . " has been uploaded.";
    } else {
      echo "Sorry, there was an error uploading your file.";
    }
  
  /*if(empty($nombre)||empty($email)||empty($contraseña)){
    header("location:../Vista/registro.php?error=Error: LLena todos los campos");
  }else if ($contraseña != $confContraseña){
    header("location:../Vista/registro.php?error=Error: No es la misma contraseña");
  }else if (strlen($contraseña<8)){
    header("location:../Vista/registro.php?error=Error: La contraseña es muy corta");
  }else{
    */
    $stmt = $conn->prepare("INSERT INTO usuarios(Email, Contraseña, NomUsu, Imagen) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $email, $contraseña, $nombre, $imagen);
    $stmt->execute();
    $stmt->close();
    $conn->close();
  }
} 


/*foreach ($usuarios as $usuario) {
echo "Nombre: " . $usuario["NomUsu"] . "<br>";
}

$i=-1;
$login=false;
while($login==false){
    $i=$i+1;
    if($nombre==$usuarios[$i]["NomUsu"]&&$email==$usuarios[$i]["Email"]&&$contraseña==$usuarios[$i]["Contraseña"]){
        header("location:../Vista/perfil.php");
        $login=true;
        exit();
    }else{
        header("location:../Vista/index.php");
        $login=false;
        exit();
    }
}
*/
?>