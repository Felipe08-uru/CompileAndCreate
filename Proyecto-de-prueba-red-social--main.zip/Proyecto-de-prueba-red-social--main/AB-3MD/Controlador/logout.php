<?php
session_destroy();
 header("location:../Vista/login.php");
?>
