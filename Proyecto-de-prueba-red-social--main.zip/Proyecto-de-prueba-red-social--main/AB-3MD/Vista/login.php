<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <audio controls autoplay>
  <source src="musica.mp3" type="audio/mpeg">
</audio>
<div id="tabla">
    <div id="testBody" class="row rounded mx-auto m-4 text-center"></div>
</div>
   
   <div id="cuadro">
        <div id="encabezado">
            <h2>Iniciar sesion</h2>
        </div>
        <div id="formulario">
            <form action="../Controlador/controlador_login.php" method="POST">
                <h3>Nombre</h3>
                <input type="text" name="nombre">
                <h3>Email</h3>
                <input type="text" name="email">
                <h3>Contraseña</h3>
                <input type="password" name="contraseña"><br><br>
                <input type="submit" value="Iniciar sesión">
            </form>

            <a href="registro.php">Crear cuenta</a>

        </div>
        <script>
        // Define la URL de la API
        const apiUrl = '../Controlador/api.php/usuarios';
        // Ejecuta la solicitud GET a la API para obtener los usuarios
        fetch(apiUrl)
        .then(response => {
            if (!response.ok) {
            throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            // Llama a la función para cargar los usuarios en la tabla HTML
            loadUsuarios(data);
        })
        .catch(error => {
            console.error('Error:', error );
        });
    </script>
    <script>
    function loadUsuarios(data) {
        let table = document.createElement("table");
        table.border = "1";
        let headers = ["ID", "Nombre", "Email", "Imágen"];
        let headerRow = table.insertRow();
        headers.forEach(h => {
            let th = document.createElement("th");
            th.innerHTML = h;
            headerRow.appendChild(th);
        });
        data.forEach(u => {
            let row = table.insertRow();
            row.insertCell().innerHTML = u.id;
            row.insertCell().innerHTML = `<a href="perfil.php?perfil=${u.NomUsu}">${u.NomUsu}</a>`;
            row.insertCell().innerHTML = u.Email;
            row.insertCell().innerHTML = `<img src='../Controlador/imagenes/${u.Imagen}' alt='Imagen de usuario' style='width:100px;height:auto;'>`;
        });
        let dvTable = document.getElementById("testBody");
        dvTable.innerHTML = "";
        dvTable.appendChild(table);
    }
    </script>
</body>
</html>                