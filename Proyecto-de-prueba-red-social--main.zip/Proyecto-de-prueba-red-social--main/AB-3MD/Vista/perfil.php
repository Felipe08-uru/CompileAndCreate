<?php
session_start();
$nombre=$_GET["perfil"];

$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'ab_md';
// Establish database connection
$conn = mysqli_connect($hostname, $username, $password, $database);
// Check connection
if(!$conn){
die('Connection failed: ' . mysqli_connect_error());
}


// Make query
$query = "SELECT Imagen,id,Email FROM Usuarios WHERE NomUsu='$nombre'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result)



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php  echo "Perfil de ". $nombre; ?></title>
</head>
<body>
    <div id="perfil">
        <h1><?php echo "Hola " . $nombre;?></h1>
        <h1><?php echo "Tu email es ". $row["Email"];?></h1>
        <img src="../Controlador/imagenes/<?php echo $row['Imagen'] ?>">
        <a href="../Controlador/logout.php"> Cerrar sesión</a>
        <h1>Agregar publicacion</h1>
        <ul id="publicaciones"></ul>
        <button onclick="openModal();">Hacer publicación</button>

        <dialog id="formModal">
            <h3>Añadir elemento</h3>
            <input type="text" id="publicacion">
            <button onclick="publicar();">Publicar</button>
            <button onclick="closeModal();">Cerrar</button>
        </dialog>
    </div>

    <h1>Lista de Pokémon</h1>
<p>Ingresa un nombre o #ID de pokémon para añadirlo a la lista</p>
<label for="nombre_pokemon">Nombre / #ID</label>
<input type="text" id="nombre_pokemon">
<button onclick="añadirPokemon();">Añadir</button>
<ul id="lista_pokemon"></ul>

<script>
    async function añadirPokemon() {
        try {
            const nombre_id = document.getElementById("nombre_pokemon").value;
            if (nombre_id) {
	    // envía una solicitud GET a la API con el nombre/id del pokemon a buscar
                const response = await fetch('https://pokeapi.co/api/v2/pokemon/' + nombre_id);

                // verifica estado de la respuesta (status 200-299)
                if (!response.ok) {
                    alert("pokemon no encontrado");
                    throw new Error(`Error: ${response.status}`);
                }

    // renderiza los datos del pokémon obtenidos en un ítem de la lista
                const data = await response.json();
                const lista = document.getElementById("lista_pokemon");
                const li = document.createElement('li');
                const img = document.createElement('img');
                img.src=data["sprites"]["front_default"];
                li.textContent = data["id"] + " - " + data["name"];
                li.appendChild(img)
                lista.appendChild(li);

                const btnEliminar=document.createElement("button");
                btnEliminar.textContent="Eliminar";
                btnEliminar.addEventListener("click", function(){
                li.remove();
                });
            li.appendChild(btnEliminar);
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }
</script>


    <script>
        function openModal(){
            const modal=document.getElementById("formModal");
            modal.showModal();
        }
        function closeModal(){
            const modal=document.getElementById("formModal");
            modal.close();
        }
        function publicar() {
            const publicacion = document.getElementById("publicacion").value;
            if (publicacion != "") {
            const publicaciones = document.getElementById("publicaciones");
            const li = document.createElement('li');
            li.textContent = publicacion;
            publicaciones.appendChild(li);

            const btnEliminar=document.createElement("button");
            btnEliminar.textContent="Eliminar";
            btnEliminar.addEventListener("click", function(){
                li.remove();
            });
            li.appendChild(btnEliminar);
            } else {
            alert("Debe ingresar un nombre");
            }
        }  

    </script>
</body>
</html>