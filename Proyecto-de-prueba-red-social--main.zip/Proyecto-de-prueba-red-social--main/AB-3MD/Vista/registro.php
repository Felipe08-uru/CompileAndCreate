<?php
$error=$_GET["error"] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <audio controls autoplay>
  <source src="homero.mp3" type="audio/mpeg">
</audio>
   <div id="cuadroR">
        <div id="encabezado">
            <h2>Registro</h2>
        </div>
        <div>
            <form action="../Controlador/controlador_registro.php" method="POST"  enctype="multipart/form-data" id="formulario">
                <h3>Nombre</h3>
                <input type="text" name="nombre" id="nombre">
                <h3>Email</h3>
                <input type="text" name="email" id="email">
                <h3>Contraseña</h3>
                <input type="password" name="contraseña" id="contraseña">
                <h3> Confirmar contraseña</h3>
                <input type="password" name="confContraseña" id="contraseña2"><br>
                <h3>Foto de Perfil</h3>
                <input type="file" name="FotoPerfil" id="archivo">
                <input type="submit" value="Registrarse" id="Registro">
                <?php
                    if($error != ""){
                        echo "<h4>".$error."</h4>";
                    }
                ?>
            </form>

            <a href="login.php">Ya tengo cuenta</a>
            

        </div>
        
      <script>
             const form=document.getElementById("formulario");
             const nombre=document.getElementById("nombre");
             const email=document.getElementById("email");
             const contraseña=document.getElementById("contraseña");
             const contraseña2=document.getElementById("contraseña2");
             const archivo=document.getElementById("archivo");
            form.addEventListener("submit", function(event){
                event.preventDefault();
                if(nombre.value==""||email.value==""||contraseña.value==""||archivo.value==""){
                    alert("Completa todos los campos");
                    return;
                }else if (contraseña.value != contraseña2.value){
                    alert("No es la misma contraseña");
                    return;
                }else if (contraseña.value.length < 8){
                    alert("La contraseña es muy corta");
                    return;
                }
                form.submit();
                
            });      
                   
        </script>
</body>
</html>        