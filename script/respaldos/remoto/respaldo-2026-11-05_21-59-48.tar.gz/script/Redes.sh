hostname -I

